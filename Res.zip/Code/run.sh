#!/bin/bash
./BlackJackPlayer $1
