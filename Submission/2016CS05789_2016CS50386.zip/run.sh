#! /bin/bash

python2 blackjack_v0.py $1
